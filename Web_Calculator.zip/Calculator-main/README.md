# Calculator
It's a simple calculator using HTML - CSS - JavaScript

- This code is a simple calculator using HTML - CSS - JavaScript
- Uma calculadora simples utilizando HTML - CSS - JavaScript
- C'est une calculatrice simple qui utilise HTML - CSS - JavaScript

# Steps to execute:
- Download the entire code (Baixe o código) (Telecharge le code)
- Open up index.html. (Abra Index.html) (Ouvre Index.html)
